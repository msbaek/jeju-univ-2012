package kr.ac.jeju.practice3;

import java.util.Random;

public class RandomArithmetic {

	private final Arithmetic arithmetic;

	public RandomArithmetic() {
		super();
		arithmetic = new Arithmetic();
	}

	public RandomArithmetic(final Arithmetic arithmetic) {
		super();
		this.arithmetic = arithmetic;
	}

	public int plus(final int x) {
		final int random = random();
		return arithmetic.plus(x, random);
	}

	public int minus(final int x) {
		final int random = random();
		return arithmetic.minus(x, random);
	}

	private int random() {
		final Random random = new Random();
		return random.nextInt();
	}
}
