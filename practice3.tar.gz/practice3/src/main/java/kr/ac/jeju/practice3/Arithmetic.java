package kr.ac.jeju.practice3;

public class Arithmetic {
	public int plus(final int x, final int y) {
		return x + y;
	}

	public int minus(final int x, final int y) {
		return x - y;
	}
}
