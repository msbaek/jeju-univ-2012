package kr.ac.jeju.practice3;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RandomArithmeticTest {

	private RandomArithmetic randomArithmetic;

	@Mock
	private Arithmetic arithmetic;

	@Before
	public void before() {
		randomArithmetic = new RandomArithmetic(arithmetic);
	}

	@Test
	public void testPlus() throws Exception {
		when(arithmetic.plus(eq(1), anyInt())).thenReturn(1);

		assertThat(randomArithmetic.plus(1), is(1));

		verify(arithmetic).plus(eq(1), anyInt());
	}

	@Test
	public void testMinus() throws Exception {
		when(arithmetic.minus(eq(1), anyInt())).thenReturn(1);

		assertThat(randomArithmetic.minus(1), is(1));

		verify(arithmetic).minus(eq(1), anyInt());
	}

}
