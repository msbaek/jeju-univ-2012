package kr.ac.jeju.practice3;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

public class ArithmeticTest {

	private Arithmetic arithmetic;

	@Before
	public void before() {
		arithmetic = new Arithmetic();
	}

	@Test
	public void testPlus() {
		assertThat(arithmetic.plus(1, 2), is(3));
		assertThat(arithmetic.plus(1, 3), is(not(3)));
	}

	@Test
	public void testMinus() throws Exception {
		assertThat(arithmetic.minus(3, 1), is(2));
		assertThat(arithmetic.minus(3, 2), is(not(2)));
	}

}
