package kr.ac.jeju.usecases.interactors;

public class InvalidateException extends RuntimeException {

	private static final long serialVersionUID = 6781344188866374537L;

}
