package kr.ac.jeju.usecases.interactors;

public class NotCreatedOrderException extends RuntimeException {

	private static final long serialVersionUID = -7768434838995900407L;

}
