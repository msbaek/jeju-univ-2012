package kr.ac.jeju.function;

import fitnesse.responders.run.SuiteResponder;
import fitnesse.wiki.PageCrawlerImpl;
import fitnesse.wiki.PageData;
import fitnesse.wiki.PathParser;
import fitnesse.wiki.WikiPage;
import fitnesse.wiki.WikiPagePath;

public class FitnessExample {
	public String testableHtml(PageData pageData, boolean includeSuiteSetup) throws Exception {
		return new SetupTeardownSurrounder(pageData, includeSuiteSetup).surround();
	}

	private class SetupTeardownSurrounder {
		private PageData pageData;
		private boolean includeSuiteSetup;
		private WikiPage wikiPage;
		private String content;

		public SetupTeardownSurrounder(PageData pageData, boolean includeSuiteSetup) {
			super();
			this.pageData = pageData;
			this.includeSuiteSetup = includeSuiteSetup;
			wikiPage = pageData.getWikiPage();
			content = new String();
		}

		public String surround() throws Exception {
			if (ifTestPage()) {
				surroundPageWithSetupsAndTeardowns();
			}
			return pageData.getHtml();
		}

		private void surroundPageWithSetupsAndTeardowns() throws Exception {
			content += includeSetups();
			content += pageData.getContent();
			content += includeTeardowns();
			pageData.setContent(content);
		}

		private boolean ifTestPage() throws Exception {
			return pageData.hasAttribute("Test");
		}

		private String includeTeardowns() throws Exception {
			String teardowns = "";
			teardowns += includeInherited("TearDown", "teardown");
			if (includeSuiteSetup) {
				teardowns += includeInherited(SuiteResponder.SUITE_TEARDOWN_NAME, "teardown");
			}
			return teardowns;
		}

		private String includeSetups() throws Exception {
			String setups = "";
			if (includeSuiteSetup) {
				setups += includeInherited(SuiteResponder.SUITE_SETUP_NAME, "setup");
			}
			setups += includeInherited("SetUp", "mode");
			return setups;
		}

		private String includeInherited(String pageName, String mode) throws Exception {
			WikiPage suiteSetup = PageCrawlerImpl.getInheritedPage(pageName, wikiPage);
			if (suiteSetup != null) {
				return includePage(suiteSetup, mode);
			}
			return "";
		}

		private String includePage(WikiPage page, String mode) throws Exception {
			WikiPagePath pagePath = wikiPage.getPageCrawler().getFullPath(page);
			String pagePathName = PathParser.render(pagePath);
			return String.format("!include -%s .%s\n", mode, pagePathName);
		}
	}
}