package kr.ac.jeju.functionstructure;

public interface Stack {

	public abstract Boolean isEmpty();

	public abstract Integer getSize();

	public abstract void push(Integer element);

	public abstract int pop();

	public abstract Integer top();

	public abstract Integer find(int element);

	public class Empty extends RuntimeException {

	}

}