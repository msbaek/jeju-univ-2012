package kr.ac.jeju.functionstructure;

public class BoundedStack implements Stack {

	private Integer size = 0;
	private final int capacity;
	private int[] elements;

	public static Stack make(int capacity) {
		if (capacity < 0) {
			throw new IllegalCapacity();
		} else if (capacity == 0) {
			return new ZeroCapacityStack();
		}
		return new BoundedStack(capacity);
	}

	private BoundedStack(int capacity) {
		this.capacity = capacity;
		this.elements = new int[capacity];
	}

	@Override
	public Boolean isEmpty() {
		return size == 0;
	}

	@Override
	public Integer getSize() {
		return size;
	}

	@Override
	public void push(Integer element) {
		if (size == capacity) {
			throw new Overflow();
		}
		this.elements[size++] = element;
	}

	@Override
	public int pop() {
		if (size == 0) {
			throw new Underflow();
		}
		return elements[--size];
	}

	@Override
	public Integer top() {
		if (isEmpty()) {
			throw new Empty();
		}
		return elements[size - 1];
	}

	@Override
	public Integer find(int element) {
		for (int i = size - 1; i >= 0; i--) {
			if (elements[i] == element) {
				return (size - 1) - i;
			}
		}
		return null;
	}

	private static final class ZeroCapacityStack implements Stack {
		@Override
		public void push(Integer element) {
			throw new Overflow();
		}

		@Override
		public int pop() {
			throw new Underflow();
		}

		@Override
		public Boolean isEmpty() {
			return false;
		}

		@Override
		public Integer getSize() {
			return 0;
		}

		@Override
		public Integer top() {
			throw new Empty();
		}

		@Override
		public Integer find(int element) {
			return null;
		}
	}

	public static class Overflow extends RuntimeException {

	}

	public static class Underflow extends RuntimeException {

	}

	public static class IllegalCapacity extends RuntimeException {

	}

}
