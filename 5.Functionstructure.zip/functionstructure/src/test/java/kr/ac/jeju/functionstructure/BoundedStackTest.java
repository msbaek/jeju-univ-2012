package kr.ac.jeju.functionstructure;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

public class BoundedStackTest {

	private Stack stack;

	@Before
	public void setUp() {
		stack = BoundedStack.make(2);
	}

	@Test
	public void newlyCreatedStack_ShouldBeEmpty() {
		assertThat(stack.isEmpty(), is(true));
		assertThat(stack.getSize(), is(0));
	}

	@Test
	public void afterOnePush_StackSizeShouldBeOne() {
		stack.push(1);
		assertThat(stack.getSize(), is(1));
		assertThat(stack.isEmpty(), is(false));
	}

	@Test
	public void afterOnePushAndOnePop_ShouldBeEmpty() {
		stack.push(1);
		stack.pop();
		assertThat(stack.isEmpty(), is(true));
	}

	@Test(expected = BoundedStack.Overflow.class)
	public void whenPushedPastLimit_StackOverflows() {
		stack.push(1);
		stack.push(1);
		stack.push(1);
	}

	@Test(expected = BoundedStack.Underflow.class)
	public void whenEmptyStackIsPopped_ShouldThrowUnderflow() {
		stack.pop();
	}

	@Test
	public void whenOneIsPushed_OneIsPopped() {
		stack.push(1);
		assertThat(stack.pop(), is(1));
	}

	@Test
	public void whenOneAndTwoArePushed_TwoAndOneArePopped() {
		stack.push(1);
		stack.push(2);
		assertThat(stack.pop(), is(2));
		assertThat(stack.pop(), is(1));
	}

	@Test(expected = BoundedStack.IllegalCapacity.class)
	public void whenCreatingStackWithNegativeSize_ShouldThrowIllegalCapacity() {
		BoundedStack.make(-1);
	}

	@Test(expected = BoundedStack.Overflow.class)
	public void whenCreatingStackWithZeroCapacity_AnyPushShouldOverflow() {
		stack = BoundedStack.make(0);
		stack.push(1);
	}

	@Test
	public void whenOneIsPushed_OneIsOnTop() {
		stack.push(1);
		assertThat(stack.top(), is(1));
	}

	@Test(expected = Stack.Empty.class)
	public void whenStackIsEmpty_TopThrowsEmpty() {
		stack.top();
	}

	@Test(expected = Stack.Empty.class)
	public void withZeroCapacityStack_TopThrowsEmpty() {
		stack = BoundedStack.make(0);
		stack.top();
	}

	@Test
	public void givenStackWithOneTwoPushed_FindOne() {
		stack.push(1);
		stack.push(2);
		assertThat(stack.find(1), is(1));
		assertThat(stack.find(2), is(0));
	}

	@Test
	public void givenStackWithNo2_Find2SoundReturnNull() {
		assertThat(stack.find(2), is(nullValue()));
	}
}
